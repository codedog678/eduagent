"""python -m evals.optimization.cli：prepare / optimize / compare。"""

import argparse
from datetime import datetime, timezone
from importlib.metadata import version
import json
from pathlib import Path
import tempfile

from config.settings import settings
from core.llm_service import get_llm_service
from core.versions import public_runtime_config
from evals.io import write_json
from evals.live_runner import code_revision
from evals.optimization.adapter import TutorGEPAAdapter
from evals.optimization.budget import OptimizationStopped
from evals.optimization.protocol import (
    GEPA_VERSION, SCHEMA, digest,
    load_policy, load_protocol, policy_artifact, prepare_protocol, seed_candidate,
)
from evals.optimization.gates import acceptance
from evals.optimization.judge_v3 import JUDGE_MAX_CALLS


DEFAULT_DATASET = Path(__file__).resolve().parents[1] / "datasets/tutor_agent50_rsi_v2.jsonl"


def metric_request_reserve(case) -> int:
    return case.expected_model_requests_max + JUDGE_MAX_CALLS


def comparison_request_reserve(cases, repeats: int) -> int:
    return 2 * repeats * sum(metric_request_reserve(case) for case in cases)


def iteration_request_reserve(train, val, minibatch: int) -> int:
    """Reserve one worst-case GEPA iteration, validation pass, and reflection call."""
    return (
        2 * minibatch * max(metric_request_reserve(case) for case in train)
        + sum(metric_request_reserve(case) for case in val)
        + 1
    )


def run_search(adapter, protocol, cases, *, max_metric_calls=160, minibatch=3, run_dir=None,
               parent=None):
    import gepa
    if version("gepa") != GEPA_VERSION:
        raise ValueError(f"install the verified dependency gepa=={GEPA_VERSION}")
    train = [cases[cid] for cid in protocol.get("reflection_train_ids", protocol["train_ids"])]
    val = [cases[cid] for cid in protocol["dev_validation_ids"]]
    if minibatch < 1 or minibatch > len(train) or max_metric_calls <= len(val):
        raise ValueError("invalid minibatch or metric budget too small to go beyond seed validation")
    # 采用真实 GEPA 搜索/候选选择；Adapter 自定义反思请求用于统一计费。
    # 每个 metric 预留一次主 Judge 与一次 repair；实际账本只结算真实调用。
    iteration_requests = iteration_request_reserve(train, val, minibatch)
    return gepa.optimize(
        seed_candidate=seed_candidate() if parent is None else parent,
        trainset=train, valset=val, adapter=adapter,
        reflection_minibatch_size=minibatch, max_metric_calls=max_metric_calls,
        candidate_selection_strategy="pareto", module_selector="round_robin",
        skip_perfect_score=False, use_merge=False, cache_evaluation=False,
        seed=protocol["seed"], raise_on_exception=True, run_dir=run_dir,
        stop_callbacks=lambda state: (
            adapter.budget.requests + iteration_requests > adapter.budget.max_requests
            or adapter.budget.exhausted
        ),
    )


def configured_service():
    service = get_llm_service()
    if (service.provider != "deepseek" or service.model != "deepseek-flash"
            or service.thinking != "disabled" or not service._has_remote_llm()):
        raise ValueError("requires configured DeepSeek Flash with thinking disabled")
    return service


def run_remote(args):
    protocol, cases = load_protocol(args.protocol, args.dataset)
    candidate = None
    evaluation_cases = [cases[cid] for cid in protocol["dev_validation_ids"]]
    origin = None
    if args.command == "compare":
        if args.repeats != 3:
            raise ValueError("exactly three paired repeats required")
        candidate = load_policy(args.candidate)
        origin = json.loads((args.origin_run / "run.json").read_text())
        if (origin["status"] != "completed"
                or origin["protocol_sha256"] != digest(protocol)
                or origin["best_policy_sha256"] != digest(candidate)):
            raise ValueError("candidate must match a completed optimization and its frozen protocol")
        if args.holdout:
            raise ValueError("holdout requires the campaign entrypoint and bound development receipt")
    service = configured_service()
    from evals.optimization.ledger import DurableBudget, SharedLedger
    budget = DurableBudget(SharedLedger(), str(args.output.resolve()),
                           max_requests=args.max_requests, max_cny=args.max_cny)
    if args.command == "compare":
        budget.require_requests(comparison_request_reserve(evaluation_cases, args.repeats))
    args.output.mkdir(parents=True, exist_ok=False)
    record = {
        "schema": SCHEMA, "status": "running", "command": args.command,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "protocol_sha256": digest(protocol), "code_revision": code_revision(),
        "provider": service.provider, "model": service.model, "thinking": service.thinking,
        "gepa_version": GEPA_VERSION,
        "limits": {"max_requests": args.max_requests, "max_cny": args.max_cny},
        "evaluation_role": "development_validation",
    }
    write_json(args.output / "protocol.json", protocol)
    write_json(args.output / "baseline-policy.json", policy_artifact(seed_candidate()))
    try:
        all_cases = list(cases.values())
        with TutorGEPAAdapter(all_cases, protocol.get("reflection_train_ids", protocol["train_ids"]), budget, args.output,
                              service=service) as adapter:
            record["runtime"] = public_runtime_config(settings)
            if origin:
                for field in ("runtime", "provider", "model", "thinking"):
                    if origin[field] != record[field]:
                        raise ValueError(f"comparison runtime changed: {field}")
                if (origin["code_revision"]["python_source_sha256"]
                        != record["code_revision"]["python_source_sha256"]):
                    raise ValueError("source changed since optimization; start a new experiment")
            write_json(args.output / "run.json", record)
            if args.command == "optimize":
                record["search"] = {"max_metric_calls": args.max_metric_calls,
                                    "minibatch": args.minibatch, "seed": protocol["seed"]}
                write_json(args.output / "run.json", record)
                # GEPA 状态/缓存是中间产物，退出后清理；公开轨迹与策略单独持久化。
                with tempfile.TemporaryDirectory(prefix="eduagent-gepa-") as cache:
                    result = run_search(adapter, protocol, cases,
                                        max_metric_calls=args.max_metric_calls,
                                        minibatch=args.minibatch, run_dir=cache)
                best = result.best_candidate
                write_json(args.output / "best-policy.json", policy_artifact(best))
                record.update(
                    best_policy_sha256=digest(best),
                    best_validation_score=result.val_aggregate_scores[result.best_idx],
                    baseline_validation_score=result.val_aggregate_scores[0],
                    candidate_count=len(result.candidates),
                    validation_scores=result.val_aggregate_scores,
                    selection="development_candidate_only",
                    metric_calls=result.total_metric_calls,
                )
            else:
                record.update(repeats=args.repeats, candidate_sha256=digest(candidate),
                              case_ids=[c.case_id for c in evaluation_cases])
                write_json(args.output / "run.json", record)
                rows = {"baseline": [], "candidate": []}
                for repeat in range(args.repeats):
                    for index, case in enumerate(evaluation_cases):
                        order = ("baseline", "candidate") if (repeat + index) % 2 == 0 else (
                            "candidate", "baseline")
                        for label in order:
                            policy = seed_candidate() if label == "baseline" else candidate
                            row = adapter.evaluate_rows([case], policy)[0]
                            row.update(repeat=repeat, comparison_label=label)
                            write_json(args.output / "evaluations"
                                       / f"{row['evaluation_index']:05d}.json", row)
                            rows[label].append(row)
                gate = acceptance(rows["baseline"], rows["candidate"])
                write_json(args.output / "comparison.json", {
                    **gate, "role": record["evaluation_role"], "repeats": args.repeats,
                })
                # 单轮命令只提供开发结果；发布资格只能由 campaign 产生。
                write_json(args.output / "selected-policy.json",
                           policy_artifact(seed_candidate()))
                record["selection"] = (
                    "development_improved_needs_holdout" if gate["passed"] else "keep_baseline"
                )
                record["gate_passed"] = gate["passed"]
            record["status"] = "completed"
    except OptimizationStopped as exc:
        record.update(status="stopped", reason=str(exc), selection="no_selection")
    except BaseException as exc:
        record.update(status="error", error_type=type(exc).__name__, selection="no_selection")
        raise
    finally:
        record["budget"] = budget.summary()
        record["finished_at"] = datetime.now(timezone.utc).isoformat()
        write_json(args.output / "budget.json", budget.summary())
        write_json(args.output / "request-ledger.json", {"requests": budget.ledger})
        write_json(args.output / "run.json", record)
    print(json.dumps({"status": record["status"], "output": str(args.output),
                      "selection": record.get("selection"),
                      "requests": budget.requests}, ensure_ascii=False))
    return 0 if record["status"] == "completed" else 2


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    prepare = sub.add_parser("prepare", help="冻结开发划分，不调用模型")
    prepare.add_argument("--dataset", type=Path, default=DEFAULT_DATASET)
    prepare.add_argument("--seed", type=int, default=42)
    prepare.add_argument("--output", type=Path, required=True)
    for name in ("optimize", "compare"):
        p = sub.add_parser(name, help="执行离线批量模型请求（产生供应商费用）")
        p.add_argument("--dataset", type=Path, default=DEFAULT_DATASET)
        p.add_argument("--protocol", type=Path, required=True)
        p.add_argument("--output", type=Path, required=True)
        p.add_argument("--max-requests", type=int, default=1200)
        p.add_argument("--max-cny", type=float, default=10.0)
        if name == "optimize":
            p.add_argument("--max-metric-calls", type=int, default=160)
            p.add_argument("--minibatch", type=int, default=3)
        else:
            p.add_argument("--candidate", type=Path, required=True)
            p.add_argument("--origin-run", type=Path, required=True)
            p.add_argument("--holdout", type=Path)
            p.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args(argv)
    if args.command == "prepare":
        if args.output.exists():
            raise ValueError("refusing to overwrite an existing protocol")
        protocol = prepare_protocol(args.dataset, args.seed)
        write_json(args.output, protocol)
        print(json.dumps({"train": len(protocol["train_ids"]),
                          "dev_validation": len(protocol["dev_validation_ids"]),
                          "provider_requests": 0}, ensure_ascii=False))
        return 0
    return run_remote(args)


if __name__ == "__main__":
    raise SystemExit(main())

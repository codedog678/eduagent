from __future__ import annotations

from contextlib import suppress
from datetime import UTC, datetime
import inspect
import json
from typing import TYPE_CHECKING

from redis.asyncio import Redis
from sqlalchemy import text
from sqlalchemy.dialects import postgresql
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.schema import CreateIndex, CreateTable

from config.settings import settings
from core.policy_store import (
    BUILTIN_HASH,
    builtin_components,
    digest as policy_digest,
)
from core.tutor_policy import fixed_components

from .broker import RedisStreamBroker
from .contracts import canonical_hash
from .metrics import DistributedMetrics
from .models import DistributedBase
from .ops_queries import OpsQueries
from .repository import DistributedRunRepository
from .policy_assignment import PolicyAssigner
from .telemetry import DurableTracer, build_optional_otel_tracer
from .worker_registry import WorkerRegistry

if TYPE_CHECKING:
    from .dispatcher import OutboxDispatcher
    from .reaper import LeaseReaper
    from .worker import RunWorker


class DistributedRuntime:
    def __init__(
        self,
        engine,
        session_factory,
        repository,
        broker,
        *,
        metrics=None,
        tracer=None,
        otel_provider=None,
        settings_obj=settings,
    ) -> None:
        self.engine = engine
        self.session_factory = session_factory
        self.repository = repository
        self.broker = broker
        self.rehearsal_broker = RedisStreamBroker(
            broker.redis,
            getattr(settings_obj, "promotion_rehearsal_stream", "eduagent:rehearsal-runs"),
            getattr(settings_obj, "promotion_rehearsal_consumer_group", "eduagent-rehearsal-run-workers"),
        )
        # Control events have no run_id and never go through a Run worker group.
        self.deployment_broker = RedisStreamBroker(
            broker.redis,
            getattr(settings_obj, "distributed_stream", "eduagent:runs") + ":policy-deployments",
            "eduagent-policy-deployment-events",
        )
        self.expert_broker = RedisStreamBroker(
            broker.redis,
            settings_obj.expert_stream,
            settings_obj.expert_consumer_group,
        )
        self.metrics = metrics or DistributedMetrics()
        self.repository.metrics = self.metrics
        self.tracer = tracer or DurableTracer(repository)
        self.otel_provider = otel_provider
        self.settings = settings_obj
        self.worker_registry = WorkerRegistry(session_factory)
        self.ops_queries = OpsQueries(
            session_factory,
            worker_stale_seconds=settings_obj.ops_worker_stale_seconds,
        )
        self.expert_repository = self._build_expert_repository()

    async def start(self) -> None:
        await check_schema_version(self.engine)
        await self.broker.ensure_group()
        await self.rehearsal_broker.ensure_group()
        await self.deployment_broker.ensure_group()
        if self.settings.distributed_experts_enabled:
            await self.expert_broker.ensure_group()

    async def close(self) -> None:
        try:
            await self.broker.redis.aclose()
        finally:
            await self.engine.dispose()
            if self.otel_provider is not None:
                with suppress(Exception):
                    self.otel_provider.shutdown()

    async def health(self) -> dict[str, str]:
        async with self.engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        redis_ok = bool(await self.broker.redis.ping())
        return {
            "status": "ok" if redis_ok else "degraded",
            "mode": "distributed-control-plane",
            "postgres": "ok",
            "redis": "ok" if redis_ok else "error",
        }

    def dispatcher(self) -> OutboxDispatcher:
        from .dispatcher import OutboxDispatcher

        return OutboxDispatcher(
            self.repository,
            self.broker,
            self.settings.distributed_outbox_batch_size,
            tracer=self.tracer,
            metrics=self.metrics,
            rehearsal_broker=self.rehearsal_broker,
            deployment_broker=self.deployment_broker,
        )

    def reaper(self) -> LeaseReaper:
        from .reaper import LeaseReaper

        return LeaseReaper(
            self.repository,
            tracer=self.tracer,
            metrics=self.metrics,
        )

    def shadow_worker(self, worker_id, executor, store_router):
        from .promotion_repository import PromotionRepository
        from .shadow_worker import ShadowWorker

        return ShadowWorker(
            worker_id, PromotionRepository(self.session_factory), executor, store_router,
            policy_assigner=self.repository.policy_assigner,
            lease_seconds=self.settings.distributed_lease_seconds,
            heartbeat_seconds=self.settings.distributed_heartbeat_seconds,
            attempt_timeout_seconds=self.settings.distributed_attempt_timeout_seconds,
            observation_recorder=self.policy_observation_recorder(),
        )

    def shadow_reaper(self, store_router):
        from .promotion_repository import PromotionRepository
        from .shadow_worker import ShadowReaper

        return ShadowReaper(PromotionRepository(self.session_factory), store_router)

    def worker(
        self,
        worker_id,
        executor,
        *,
        registry_process=None,
        allowed_environment="production",
    ) -> RunWorker:
        from .worker import RunWorker
        if hasattr(executor, "usage_recorder"):
            executor.usage_recorder = self.repository.record_attempt_usage

        return RunWorker(
            worker_id,
            self.repository,
            self.rehearsal_broker if allowed_environment == "rehearsal" else self.broker,
            executor,
            lease_seconds=self.settings.distributed_lease_seconds,
            heartbeat_seconds=self.settings.distributed_heartbeat_seconds,
            max_attempts=self.settings.distributed_max_attempts,
            pause_before_commit_seconds=(
                self.settings.distributed_demo_pause_before_commit_seconds
            ),
            tracer=self.tracer,
            metrics=self.metrics,
            registry_process=registry_process,
            allowed_environment=allowed_environment,
            observation_recorder=self.policy_observation_recorder(),
        )

    def policy_observation_recorder(self):
        from .policy_health import PolicyObservationRecorder

        return PolicyObservationRecorder(self.session_factory, metrics=self.metrics)

    def policy_health(self):
        from .policy_health import PolicyHealthProcess
        from .promotion_repository import PromotionRepository

        return PolicyHealthProcess(
            PromotionRepository(self.session_factory), metrics=self.metrics,
            enabled=self.settings.promotion_enabled,
        )

    def expert_gateway(self):
        if not self.settings.distributed_experts_enabled:
            return None
        from core.llm_service import get_llm_service

        from .expert_engine import ExpertEngine
        from .expert_gateway import (
            DurableExpertGateway,
            InlineExpertGateway,
        )

        return DurableExpertGateway(
            self.expert_repository,
            InlineExpertGateway(
                ExpertEngine(get_llm_service())
            ),
            poll_seconds=self.settings.expert_result_poll_seconds,
            metrics=self.metrics,
        )

    def expert_dispatcher(self):
        from .expert_dispatcher import ExpertDispatcher

        return ExpertDispatcher(
            self.expert_repository,
            self.expert_broker,
            self.settings.distributed_outbox_batch_size,
            metrics=self.metrics,
        )

    def expert_reaper(self):
        from .expert_reaper import ExpertReaper

        return ExpertReaper(
            self.expert_repository,
            metrics=self.metrics,
        )

    def expert_worker(
        self,
        worker_id,
        engine,
        *,
        roles,
        registry_process=None,
    ):
        from .expert_worker import ExpertWorker

        return ExpertWorker(
            worker_id,
            self.expert_repository,
            self.expert_broker,
            engine,
            roles=roles,
            lease_seconds=self.settings.expert_lease_seconds,
            heartbeat_seconds=self.settings.expert_heartbeat_seconds,
            poll_block_ms=self.settings.expert_poll_block_ms,
            pause_before_result_seconds=(
                self.settings.expert_demo_pause_before_result_seconds
            ),
            metrics=self.metrics,
            registry_process=registry_process,
        )

    def _build_expert_repository(self):
        from .expert_repository import ExpertJobRepository

        return ExpertJobRepository(
            self.session_factory,
            queued_limit_per_role=(
                self.settings.expert_queued_limit_per_role
            ),
            running_limit_per_role=(
                self.settings.expert_running_limit_per_role
            ),
            queued_payload_bytes_limit=(
                self.settings.expert_queued_payload_bytes_limit
            ),
            max_payload_bytes=self.settings.expert_max_payload_bytes,
            max_job_seconds=self.settings.expert_max_job_seconds,
            retry_base_seconds=self.settings.expert_retry_base_seconds,
            retry_max_seconds=self.settings.expert_retry_max_seconds,
        )


def build_runtime(settings_obj=settings) -> DistributedRuntime:
    from .broker import RedisRunBroker

    engine = create_async_engine(
        settings_obj.effective_distributed_database_url,
        pool_pre_ping=True,
    )
    factory = async_sessionmaker(engine, expire_on_commit=False)
    repository = DistributedRunRepository(
        factory,
        max_attempts=settings_obj.distributed_max_attempts,
        parent_timeout_seconds=(
            settings_obj.distributed_attempt_timeout_seconds
        ),
        policy_assigner=PolicyAssigner(
            signing_secret=(settings_obj.promotion_rehearsal_secret.get_secret_value().encode()
                            if settings_obj.promotion_enabled else None),
            assignment_secret=(settings_obj.promotion_assignment_secret.get_secret_value().encode()
                               if settings_obj.promotion_enabled else None),
            allow_fault_injection=settings_obj.promotion_fault_injection_enabled,
            settings_obj=settings_obj,
        ),
    )
    broker = RedisRunBroker(
        Redis.from_url(
            settings_obj.distributed_redis_url,
            decode_responses=True,
        ),
        settings_obj.distributed_stream,
        settings_obj.distributed_consumer_group,
    )
    metrics = DistributedMetrics()
    otel_tracer, otel_provider = build_optional_otel_tracer(
        settings_obj.otel_exporter_otlp_endpoint
    )
    return DistributedRuntime(
        engine,
        factory,
        repository,
        broker,
        metrics=metrics,
        tracer=DurableTracer(repository, otel_tracer),
        otel_provider=otel_provider,
        settings_obj=settings_obj,
    )


async def upgrade_m1_schema(
    connection,
    parent_timeout_seconds: float,
) -> None:
    await connection.execute(
        text(
            "ALTER TABLE distributed_run_attempts "
            "ADD COLUMN IF NOT EXISTS deadline_at TIMESTAMPTZ"
        )
    )
    await connection.execute(
        text(
            "UPDATE distributed_run_attempts "
            "SET deadline_at = started_at + "
            "make_interval(secs => CAST(:timeout AS double precision)) "
            "WHERE deadline_at IS NULL"
        ),
        {"timeout": parent_timeout_seconds},
    )
    await connection.execute(
        text(
            "ALTER TABLE distributed_run_attempts "
            "ALTER COLUMN deadline_at SET NOT NULL"
        )
    )


BUILTIN_POLICY_COMPONENTS = builtin_components()
BUILTIN_POLICY_HASH = BUILTIN_HASH
BUILTIN_FIXED_COMPONENTS_HASH = policy_digest(fixed_components())
BUILTIN_RUNTIME_HASH = canonical_hash({"runtime": "builtin"})
BUILTIN_PROTOCOL_HASH = canonical_hash({"protocol": "builtin"})
BUILTIN_PROPOSER_HASH = canonical_hash({"proposer": "system"})
PRODUCTION_DEPLOYMENT_ID = "00000000-0000-0000-0000-000000000001"
REHEARSAL_DEPLOYMENT_ID = "00000000-0000-0000-0000-000000000002"
DEFAULT_POLICY_THRESHOLDS = {
    "candidate_min_runs": 20,
    "stable_min_runs": 20,
    "window_max_runs": 50,
    "commit_failure_rate": "0.05",
    "terminal_failure_rate": "0.10",
    "latency_increase_rate": "0.50",
    "mean_cost_increase_rate": "0.30",
    "unknown_rate": "0.10",
    "relative_epsilon": "0.000001",
}
DEFAULT_POLICY_THRESHOLDS_HASH = canonical_hash(DEFAULT_POLICY_THRESHOLDS)


async def upgrade_m3_schema(connection) -> None:
    if connection.dialect.name != "postgresql":
        return
    old_observation_columns = set((await connection.execute(text(
        "SELECT column_name FROM information_schema.columns "
        "WHERE table_schema=current_schema() AND table_name='policy_observations'"
    ))).scalars())
    health_columns = {
        "distributed_run_attempts": {
            "usage_summary": "JSON", "fault_injected": "BOOLEAN NOT NULL DEFAULT false",
        },
        "policy_observations": {
            "structured_decision_count": "INTEGER", "unknown_decision_count": "INTEGER",
            "rehearsal_id": "VARCHAR(128)", "operation": "VARCHAR(64) NOT NULL DEFAULT 'learning_task'",
            "server_error_code": "VARCHAR(128)", "fault_injected": "BOOLEAN NOT NULL DEFAULT false",
        },
        "policy_health_windows": {
            "deployment_version": "INTEGER", "thresholds_hash": "VARCHAR(64)",
            "observation_keys": "JSON",
        },
    }
    for table, columns in health_columns.items():
        for name, sql_type in columns.items():
            await connection.execute(text(
                f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS {name} {sql_type}"
            ))
    derived_columns = {
        "operation": "runs.operation",
        "rehearsal_id": "runs.rehearsal_id",
        "fault_injected": "observations.injected",
        "server_error_code": (
            "CASE WHEN observations.cohort = 'shadow' THEN "
            "(SELECT shadows.error_code FROM policy_shadow_executions shadows "
            "WHERE shadows.parent_run_id=observations.run_id "
            "AND shadows.deployment_id=observations.deployment_id) ELSE runs.error_code END"
        ),
    }
    added = set(derived_columns) - old_observation_columns
    if added:
        # 只在真实旧列缺失时回填权威 PG 字段；同一事务末尾重新安装 append-only。
        await connection.execute(text(
            "DROP TRIGGER IF EXISTS trg_policy_observations_append_only ON policy_observations"
        ))
        assignments = ", ".join(f"{name}={derived_columns[name]}" for name in sorted(added))
        await connection.execute(text(
            f"UPDATE policy_observations observations SET {assignments} "
            "FROM distributed_runs runs WHERE runs.id=observations.run_id"
        ))
    await connection.execute(text(
        "CREATE INDEX IF NOT EXISTS ix_policy_observation_health_window ON policy_observations "
        "(deployment_id, cohort, metric_contract_version, observed_at, observation_key)"
    ))
    await connection.execute(text(
        "CREATE INDEX IF NOT EXISTS ix_policy_observation_health_bucket ON policy_observations "
        "(deployment_id, cohort, metric_contract_version, rehearsal_id, operation, observed_at, observation_key)"
    ))

    run_columns = {
        "deployment_id": "VARCHAR(36)",
        "effective_policy_hash": "VARCHAR(64)",
        "policy_cohort": "VARCHAR(16)",
        "assignment_key_hash": "VARCHAR(64)",
        "assignment_reason": "VARCHAR(128)",
        "state_namespace": "VARCHAR(128)",
        "rehearsal_id": "VARCHAR(128)",
        "rehearsal_fault_profile": "VARCHAR(32) DEFAULT 'none'",
        "policy_binding": "JSON",
    }
    expert_columns = {
        "deployment_id": "VARCHAR(36)",
        "state_namespace": "VARCHAR(128)",
    }
    shadow_columns = {
        "input_hash": "VARCHAR(64)",
        "payload_reference": "JSON",
        "policy_binding": "JSON",
        "deployment_version": "INTEGER",
        "attempt_count": "INTEGER NOT NULL DEFAULT 0",
        "max_attempts": "INTEGER NOT NULL DEFAULT 3",
        "error_code": "VARCHAR(64)",
        "started_at": "TIMESTAMP WITH TIME ZONE",
        "finished_at": "TIMESTAMP WITH TIME ZONE",
        "deadline_at": "TIMESTAMP WITH TIME ZONE",
    }
    for name, sql_type in shadow_columns.items():
        await connection.execute(text(
            f"ALTER TABLE policy_shadow_executions ADD COLUMN IF NOT EXISTS {name} {sql_type}"
        ))
    for name, sql_type in run_columns.items():
        await connection.execute(
            text(
                f"ALTER TABLE distributed_runs "
                f"ADD COLUMN IF NOT EXISTS {name} {sql_type}"
            )
        )
    for name, sql_type in expert_columns.items():
        await connection.execute(
            text(
                f"ALTER TABLE distributed_expert_jobs "
                f"ADD COLUMN IF NOT EXISTS {name} {sql_type}"
            )
        )

    # Transactional DDL holds the table lock until the trigger is reinstalled.
    # This permits one-time NULL-binding backfill when upgrading a Task4 schema
    # or a partially migrated schema, without exposing mutable live bindings.
    await connection.execute(text(
        "DROP TRIGGER IF EXISTS trg_distributed_run_binding_immutable ON distributed_runs"
    ))

    now = datetime.now(UTC)
    await connection.execute(
        text(
            "INSERT INTO policy_artifacts ("
            "policy_hash, parent_policy_hash, components, "
            "fixed_components_hash, runtime_hash, source_revision, "
            "protocol_hash, proposer_hash, data_role, evidence_bindings, "
            "created_at"
            ") VALUES ("
            ":policy_hash, NULL, CAST(:components AS JSON), "
            ":fixed_hash, :runtime_hash, 'builtin', :protocol_hash, "
            ":proposer_hash, 'builtin', CAST('{}' AS JSON), :created_at"
            ") ON CONFLICT (policy_hash) DO NOTHING"
        ),
        {
            "policy_hash": BUILTIN_POLICY_HASH,
            "components": json.dumps(
                BUILTIN_POLICY_COMPONENTS,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ),
            "fixed_hash": BUILTIN_FIXED_COMPONENTS_HASH,
            "runtime_hash": BUILTIN_RUNTIME_HASH,
            "protocol_hash": BUILTIN_PROTOCOL_HASH,
            "proposer_hash": BUILTIN_PROPOSER_HASH,
            "created_at": now,
        },
    )
    for environment, deployment_id in (
        ("production", PRODUCTION_DEPLOYMENT_ID),
        ("rehearsal", REHEARSAL_DEPLOYMENT_ID),
    ):
        await connection.execute(
            text(
                "INSERT INTO policy_deployments ("
                "deployment_id, environment, version, state, "
                "candidate_policy_hash, stable_policy_hash, "
                "previous_stable_deployment_id, traffic_basis_points, "
                "assignment_salt_id, thresholds, thresholds_hash, "
                "required_receipts, command_id, reason, actor, created_at"
                ") VALUES ("
                ":deployment_id, :environment, 1, 'registered', NULL, "
                ":policy_hash, NULL, 0, 'builtin', "
                "CAST(:thresholds AS JSON), :thresholds_hash, "
                "CAST('[]' AS JSON), :command_id, 'builtin bootstrap', "
                "'system', :created_at"
                ") ON CONFLICT (deployment_id) DO NOTHING"
            ),
            {
                "deployment_id": deployment_id,
                "environment": environment,
                "policy_hash": BUILTIN_POLICY_HASH,
                "thresholds": (
                    '{"candidate_min_runs":20,"commit_failure_rate":"0.05",'
                    '"latency_increase_rate":"0.50",'
                    '"mean_cost_increase_rate":"0.30",'
                    '"relative_epsilon":"0.000001","stable_min_runs":20,'
                    '"terminal_failure_rate":"0.10","unknown_rate":"0.10",'
                    '"window_max_runs":50}'
                ),
                "thresholds_hash": DEFAULT_POLICY_THRESHOLDS_HASH,
                "command_id": f"bootstrap-{environment}",
                "created_at": now,
            },
        )
        await connection.execute(
            text(
                "INSERT INTO policy_environment_heads ("
                "environment, current_deployment_id, current_version, "
                "updated_at"
                ") VALUES (:environment, :deployment_id, 1, :updated_at) "
                "ON CONFLICT (environment) DO NOTHING"
            ),
            {
                "environment": environment,
                "deployment_id": deployment_id,
                "updated_at": now,
            },
        )
        await connection.execute(
            text(
                "INSERT INTO policy_audit_events ("
                "event_id, environment, deployment_id, event_type, "
                "command_id, actor, reason, details, created_at"
                ") VALUES ("
                ":event_id, :environment, :deployment_id, 'bootstrap', "
                ":command_id, 'system', 'builtin bootstrap', "
                "CAST('{}' AS JSON), :created_at"
                ") ON CONFLICT (event_id) DO NOTHING"
            ),
            {
                "event_id": (
                    "00000000-0000-0000-0000-000000000011"
                    if environment == "production"
                    else "00000000-0000-0000-0000-000000000012"
                ),
                "environment": environment,
                "deployment_id": deployment_id,
                "command_id": f"bootstrap-{environment}",
                "created_at": now,
            },
        )

    await connection.execute(
        text(
            "UPDATE distributed_runs SET "
            "deployment_id = COALESCE(deployment_id, :deployment_id), "
            "effective_policy_hash = COALESCE("
            "effective_policy_hash, :policy_hash), "
            "policy_cohort = COALESCE(policy_cohort, 'stable'), "
            "assignment_key_hash = COALESCE("
            "assignment_key_hash, :policy_hash), "
            "assignment_reason = COALESCE("
            "assignment_reason, 'legacy_backfill'), "
            "state_namespace = COALESCE(state_namespace, 'production'), "
            "rehearsal_fault_profile = COALESCE("
            "rehearsal_fault_profile, 'none') "
            "WHERE deployment_id IS NULL "
            "OR effective_policy_hash IS NULL "
            "OR policy_cohort IS NULL "
            "OR assignment_key_hash IS NULL "
            "OR assignment_reason IS NULL "
            "OR state_namespace IS NULL "
            "OR rehearsal_fault_profile IS NULL"
        ),
        {
            "deployment_id": PRODUCTION_DEPLOYMENT_ID,
            "policy_hash": BUILTIN_POLICY_HASH,
        },
    )
    await connection.execute(
        text(
            "UPDATE distributed_expert_jobs AS jobs SET "
            "deployment_id = COALESCE(jobs.deployment_id, runs.deployment_id), "
            "state_namespace = COALESCE("
            "jobs.state_namespace, runs.state_namespace) "
            "FROM distributed_runs AS runs "
            "WHERE jobs.parent_run_id = runs.id "
            "AND (jobs.deployment_id IS NULL OR jobs.state_namespace IS NULL)"
        )
    )
    for source_table, source_column in (
        ("distributed_runs", "effective_policy_hash"),
        ("distributed_expert_jobs", "policy_hash"),
    ):
        await connection.execute(
            text(
                "INSERT INTO policy_artifacts ("
                "policy_hash, parent_policy_hash, components, "
                "fixed_components_hash, runtime_hash, source_revision, "
                "protocol_hash, proposer_hash, data_role, evidence_bindings, "
                "created_at"
                ") SELECT "
                "source.policy_hash, NULL, "
                "json_build_object("
                "'retrieval_rules', "
                "'Legacy policy content is unavailable after M3 schema "
                "migration; this placeholder is not release eligible.'"
                "), "
                ":fixed_hash, :runtime_hash, 'legacy-m3-backfill', "
                ":protocol_hash, :proposer_hash, 'legacy', "
                "json_build_object("
                "'migration', 'm3', "
                "'legacy_policy_hash', source.policy_hash, "
                "'release_eligible', false"
                "), :created_at "
                f"FROM (SELECT DISTINCT {source_column} AS policy_hash "
                f"FROM {source_table} WHERE {source_column} IS NOT NULL"
                ") AS source "
                "LEFT JOIN policy_artifacts AS artifacts "
                "ON artifacts.policy_hash = source.policy_hash "
                "WHERE artifacts.policy_hash IS NULL "
                "ON CONFLICT (policy_hash) DO NOTHING"
            ),
            {
                "fixed_hash": BUILTIN_FIXED_COMPONENTS_HASH,
                "runtime_hash": BUILTIN_RUNTIME_HASH,
                "protocol_hash": BUILTIN_PROTOCOL_HASH,
                "proposer_hash": BUILTIN_PROPOSER_HASH,
                "created_at": now,
            },
        )

    # Historical builtin Runs get explicit frozen components, never a mutable
    # head lookup at claim time. Unknown legacy hashes remain non-executable.
    await connection.execute(
        text(
            "UPDATE distributed_runs AS runs SET policy_binding = json_build_object("
            "'deployment_id', runs.deployment_id, 'environment', deployments.environment, "
            "'effective_policy_hash', runs.effective_policy_hash, "
            "'components', CAST(:components AS JSON), 'policy_cohort', runs.policy_cohort, "
            "'assignment_key_hash', runs.assignment_key_hash, "
            "'assignment_reason', runs.assignment_reason, 'state_namespace', runs.state_namespace, "
            "'rehearsal_id', runs.rehearsal_id, "
            "'rehearsal_fault_profile', runs.rehearsal_fault_profile) "
            "FROM policy_deployments AS deployments "
            "WHERE runs.deployment_id = deployments.deployment_id "
            "AND runs.policy_binding IS NULL AND runs.effective_policy_hash = :policy_hash"
        ),
        {"components": json.dumps(BUILTIN_POLICY_COMPONENTS), "policy_hash": BUILTIN_POLICY_HASH},
    )

    defaults = {
        "deployment_id": PRODUCTION_DEPLOYMENT_ID,
        "effective_policy_hash": BUILTIN_POLICY_HASH,
        "policy_cohort": "stable",
        "assignment_key_hash": BUILTIN_POLICY_HASH,
        "assignment_reason": "legacy_backfill",
        "state_namespace": "production",
        "rehearsal_fault_profile": "none",
    }
    for column, default in defaults.items():
        await connection.execute(
            text(
                f"ALTER TABLE distributed_runs ALTER COLUMN {column} "
                f"SET DEFAULT '{default}'"
            )
        )
        await connection.execute(
            text(
                f"ALTER TABLE distributed_runs ALTER COLUMN {column} "
                "SET NOT NULL"
            )
        )
    for column, default in (
        ("deployment_id", PRODUCTION_DEPLOYMENT_ID),
        ("state_namespace", "production"),
    ):
        await connection.execute(
            text(
                f"ALTER TABLE distributed_expert_jobs ALTER COLUMN {column} "
                f"SET DEFAULT '{default}'"
            )
        )
        await connection.execute(
            text(
                f"ALTER TABLE distributed_expert_jobs ALTER COLUMN {column} "
                "SET NOT NULL"
            )
        )

    constraints = {
        "fk_distributed_run_deployment": (
            "distributed_runs",
            "FOREIGN KEY (deployment_id) "
            "REFERENCES policy_deployments(deployment_id)",
        ),
        "fk_distributed_run_effective_policy": (
            "distributed_runs",
            "FOREIGN KEY (effective_policy_hash) "
            "REFERENCES policy_artifacts(policy_hash)",
        ),
        "fk_expert_job_deployment": (
            "distributed_expert_jobs",
            "FOREIGN KEY (deployment_id) "
            "REFERENCES policy_deployments(deployment_id)",
        ),
        "fk_expert_job_policy_artifact": (
            "distributed_expert_jobs",
            "FOREIGN KEY (policy_hash) "
            "REFERENCES policy_artifacts(policy_hash)",
        ),
    }
    for name, (table_name, definition) in constraints.items():
        await connection.execute(
            text(
                "DO $$ BEGIN "
                f"IF NOT EXISTS (SELECT 1 FROM pg_constraint "
                f"WHERE conname = '{name}' "
                f"AND conrelid = '{table_name}'::regclass) THEN "
                f"ALTER TABLE {table_name} ADD CONSTRAINT {name} "
                f"{definition}; "
                "END IF; END $$"
            )
        )
    await connection.execute(
        text(
            "DO $$ BEGIN "
            "IF EXISTS (SELECT 1 FROM pg_constraint "
            "WHERE conname = "
            "'uq_policy_audit_command_deployment_event_type' "
            "AND conrelid = 'policy_audit_events'::regclass "
            "AND pg_get_constraintdef(oid) <> 'UNIQUE (command_id)') THEN "
            "ALTER TABLE policy_audit_events DROP CONSTRAINT "
            "uq_policy_audit_command_deployment_event_type; "
            "END IF; "
            "IF NOT EXISTS (SELECT 1 FROM pg_constraint "
            "WHERE conname = "
            "'uq_policy_audit_command_deployment_event_type' "
            "AND conrelid = 'policy_audit_events'::regclass) THEN "
            "ALTER TABLE policy_audit_events ADD CONSTRAINT "
            "uq_policy_audit_command_deployment_event_type "
            "UNIQUE (command_id); "
            "END IF; END $$"
        )
    )
    await connection.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_distributed_run_deployment "
            "ON distributed_runs (deployment_id)"
        )
    )
    await connection.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_distributed_run_effective_policy "
            "ON distributed_runs (effective_policy_hash)"
        )
    )
    await connection.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_expert_job_deployment "
            "ON distributed_expert_jobs (deployment_id)"
        )
    )
    await connection.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_expert_job_policy "
            "ON distributed_expert_jobs (policy_hash)"
        )
    )

    await connection.execute(
        text(
            "CREATE OR REPLACE FUNCTION reject_m3_append_only_change() "
            "RETURNS trigger AS $$ BEGIN "
            "RAISE EXCEPTION '% is append-only', TG_TABLE_NAME; "
            "END; $$ LANGUAGE plpgsql"
        )
    )
    for table_name in (
        "policy_artifacts",
        "policy_gate_receipts",
        "policy_deployments",
        "policy_observations",
        "policy_health_windows",
        "policy_audit_events",
    ):
        trigger_name = f"trg_{table_name}_append_only"
        await connection.execute(
            text(
                f"DROP TRIGGER IF EXISTS {trigger_name} ON {table_name}"
            )
        )
        await connection.execute(
            text(
                f"CREATE TRIGGER {trigger_name} "
                f"BEFORE UPDATE OR DELETE ON {table_name} "
                "FOR EACH ROW EXECUTE FUNCTION "
                "reject_m3_append_only_change()"
            )
        )
    await connection.execute(
        text(
            "CREATE OR REPLACE FUNCTION reject_run_binding_change() "
            "RETURNS trigger AS $$ BEGIN "
            "IF NEW.policy_binding::jsonb IS DISTINCT FROM OLD.policy_binding::jsonb "
            "OR NEW.deployment_id IS DISTINCT FROM OLD.deployment_id "
            "OR NEW.effective_policy_hash IS DISTINCT FROM "
            "OLD.effective_policy_hash "
            "OR NEW.policy_cohort IS DISTINCT FROM OLD.policy_cohort "
            "OR NEW.assignment_key_hash IS DISTINCT FROM "
            "OLD.assignment_key_hash "
            "OR NEW.assignment_reason IS DISTINCT FROM OLD.assignment_reason "
            "OR NEW.state_namespace IS DISTINCT FROM OLD.state_namespace "
            "OR NEW.rehearsal_id IS DISTINCT FROM OLD.rehearsal_id "
            "OR NEW.rehearsal_fault_profile IS DISTINCT FROM "
            "OLD.rehearsal_fault_profile THEN "
            "RAISE EXCEPTION 'distributed run assignment is immutable'; "
            "END IF; "
            "RETURN NEW; "
            "END; $$ LANGUAGE plpgsql"
        )
    )
    await connection.execute(
        text(
            "DROP TRIGGER IF EXISTS trg_distributed_run_binding_immutable "
            "ON distributed_runs"
        )
    )
    await connection.execute(
        text(
            "CREATE TRIGGER trg_distributed_run_binding_immutable "
            "BEFORE UPDATE ON distributed_runs "
            "FOR EACH ROW EXECUTE FUNCTION reject_run_binding_change()"
        )
    )
    await connection.execute(
        text(
            "CREATE OR REPLACE FUNCTION reject_expert_binding_change() "
            "RETURNS trigger AS $$ BEGIN "
            "IF NEW.deployment_id IS DISTINCT FROM OLD.deployment_id "
            "OR NEW.state_namespace IS DISTINCT FROM OLD.state_namespace "
            "OR NEW.policy_hash IS DISTINCT FROM OLD.policy_hash THEN "
            "RAISE EXCEPTION 'distributed expert assignment is immutable'; "
            "END IF; "
            "RETURN NEW; "
            "END; $$ LANGUAGE plpgsql"
        )
    )
    await connection.execute(
        text(
            "DROP TRIGGER IF EXISTS trg_expert_job_binding_immutable "
            "ON distributed_expert_jobs"
        )
    )
    await connection.execute(
        text(
            "CREATE TRIGGER trg_expert_job_binding_immutable "
            "BEFORE UPDATE ON distributed_expert_jobs "
            "FOR EACH ROW EXECUTE FUNCTION reject_expert_binding_change()"
        )
    )
    await connection.execute(
        text(
            "CREATE OR REPLACE FUNCTION reject_invalid_shadow_change() "
            "RETURNS trigger AS $$ BEGIN "
            "IF TG_OP = 'DELETE' THEN "
            "RAISE EXCEPTION '% rows cannot be deleted', TG_TABLE_NAME; "
            "END IF; "
            "IF OLD.status NOT IN ('queued', 'leased', 'running') THEN "
            "RAISE EXCEPTION '% terminal row is append-only', TG_TABLE_NAME; "
            "END IF; "
            "IF NEW.shadow_id IS DISTINCT FROM OLD.shadow_id "
            "OR NEW.parent_run_id IS DISTINCT FROM OLD.parent_run_id "
            "OR NEW.deployment_id IS DISTINCT FROM OLD.deployment_id "
            "OR NEW.policy_hash IS DISTINCT FROM OLD.policy_hash "
            "OR NEW.input_hash IS DISTINCT FROM OLD.input_hash "
            "OR NEW.payload_reference::jsonb IS DISTINCT FROM OLD.payload_reference::jsonb "
            "OR NEW.policy_binding::jsonb IS DISTINCT FROM OLD.policy_binding::jsonb "
            "OR NEW.deployment_version IS DISTINCT FROM OLD.deployment_version "
            "OR NEW.max_attempts IS DISTINCT FROM OLD.max_attempts "
            "OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN "
            "RAISE EXCEPTION '% identity is immutable', TG_TABLE_NAME; "
            "END IF; "
            "RETURN NEW; "
            "END; $$ LANGUAGE plpgsql"
        )
    )
    await connection.execute(
        text(
            "DROP TRIGGER IF EXISTS trg_policy_shadow_terminal_immutable "
            "ON policy_shadow_executions"
        )
    )
    await connection.execute(
        text(
            "CREATE TRIGGER trg_policy_shadow_terminal_immutable "
            "BEFORE UPDATE OR DELETE ON policy_shadow_executions "
            "FOR EACH ROW EXECUTE FUNCTION reject_invalid_shadow_change()"
        )
    )


SCHEMA_VERSION = 3
SCHEMA_MIGRATION_LOCK = 0x4544554D33534348


def schema_contract_hash() -> str:
    """Bind the marker to ORM DDL and the existing explicit upgrade functions."""
    dialect = postgresql.dialect()
    tables = sorted(DistributedBase.metadata.tables.values(), key=lambda table: table.name)
    return canonical_hash({
        "version": SCHEMA_VERSION,
        "tables": [str(CreateTable(table).compile(dialect=dialect)) for table in tables],
        "indexes": sorted(
            str(CreateIndex(index).compile(dialect=dialect))
            for table in tables for index in table.indexes
        ),
        "upgrades": [
            inspect.getsource(upgrade_m1_schema),
            inspect.getsource(upgrade_m3_schema),
        ],
        "builtin_policy": BUILTIN_POLICY_HASH,
        "thresholds": DEFAULT_POLICY_THRESHOLDS_HASH,
    })


class SchemaVersionMismatch(RuntimeError):
    pass


async def check_schema_version(engine) -> None:
    """Normal startup is read-only and never repairs a missing/stale marker."""
    message = (
        "distributed schema marker is missing or incompatible; drain API traffic "
        "and workers, then run python -m core.distributed.cli migrate"
    )
    async with engine.begin() as connection:
        if connection.dialect.name != "postgresql":
            raise SchemaVersionMismatch("distributed schema requires PostgreSQL")
        await connection.execute(text("SET TRANSACTION READ ONLY"))
        marker = await connection.scalar(text(
            "SELECT to_regclass(format('%I.distributed_schema_version', current_schema()))"
        ))
        if marker is None:
            raise SchemaVersionMismatch(message)
        row = (await connection.execute(text(
            "SELECT version, schema_hash FROM distributed_schema_version WHERE id = 1"
        ))).one_or_none()
        if row is None or tuple(row) != (SCHEMA_VERSION, schema_contract_hash()):
            raise SchemaVersionMismatch(message)


async def migrate_schema(
    engine,
    parent_timeout_seconds: float = settings.distributed_attempt_timeout_seconds,
) -> None:
    """One-shot transactional migration; all API traffic/workers must be drained."""
    async with engine.begin() as connection:
        if connection.dialect.name != "postgresql":
            raise RuntimeError("distributed schema migration requires PostgreSQL")
        await connection.execute(
            text("SELECT pg_advisory_xact_lock(:key)"),
            {"key": SCHEMA_MIGRATION_LOCK},
        )
        await connection.run_sync(DistributedBase.metadata.create_all)
        await upgrade_m1_schema(connection, parent_timeout_seconds)
        await upgrade_m3_schema(connection)
        # Publish the authoritative marker only after every upgrade succeeds.
        await connection.execute(text(
            "CREATE TABLE IF NOT EXISTS distributed_schema_version ("
            "id SMALLINT PRIMARY KEY CHECK (id = 1), "
            "version INTEGER NOT NULL, schema_hash VARCHAR(64) NOT NULL, "
            "migrated_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp())"
        ))
        await connection.execute(text(
            "INSERT INTO distributed_schema_version (id, version, schema_hash) "
            "VALUES (1, :version, :schema_hash) ON CONFLICT (id) DO UPDATE SET "
            "version = EXCLUDED.version, schema_hash = EXCLUDED.schema_hash, "
            "migrated_at = clock_timestamp()"
        ), {"version": SCHEMA_VERSION, "schema_hash": schema_contract_hash()})


class PromotionCommandRuntime:
    """Database-only runtime for the isolated promotion command CLI."""

    def __init__(self, engine, session_factory, service, token_issuer) -> None:
        self.engine = engine
        self.session_factory = session_factory
        self.service = service
        self.token_issuer = token_issuer

    async def start(self) -> None:
        await check_schema_version(self.engine)

    async def close(self) -> None:
        await self.engine.dispose()


def build_promotion_command_runtime(settings_obj=settings) -> PromotionCommandRuntime:
    """Build promotion DB services without Redis, HTTP, workers, or Ops."""
    from .promotion_repository import PromotionRepository
    from .promotion_service import (
        PromotionCommandService,
        RehearsalTokenIssuer,
    )

    engine = create_async_engine(
        settings_obj.effective_distributed_database_url,
        pool_pre_ping=True,
    )
    factory = async_sessionmaker(engine, expire_on_commit=False)
    repository = PromotionRepository(factory)
    return PromotionCommandRuntime(
        engine,
        factory,
        PromotionCommandService(
            repository,
            authenticated_principal=(
                settings_obj.promotion_command_principal
            ),
        ),
        RehearsalTokenIssuer(
            repository,
            signing_secret=(
                settings_obj.promotion_rehearsal_secret.get_secret_value()
            ),
            assignment_secret=(
                settings_obj.promotion_assignment_secret.get_secret_value()
            ),
            allow_fault_injection=(
                settings_obj.promotion_fault_injection_enabled
            ),
        ),
    )

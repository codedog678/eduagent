"""Curriculum agent for study path recommendations and review scheduling."""

from __future__ import annotations

import logging
import json
from datetime import datetime, timedelta
from typing import Any, Optional

from agents.base import BaseAgent
from config.settings import settings
from core.event_bus import Event, EventType
from core.knowledge_graph import KnowledgeGraph, build_english_learning_graph
from core.learner_model import LearnerModel
from core.llm_service import get_llm_service
from core.spaced_repetition import ReviewItem, SpacedRepetition

logger = logging.getLogger(__name__)

MASTERY_THRESHOLD = 0.6


class ReviewReminder:
    """Student-facing review reminder."""

    def __init__(self, knowledge_id: str, retention: float, days_since_review: float):
        self.knowledge_id = knowledge_id
        self.retention = retention
        self.days_since_review = days_since_review
        self.created_at = datetime.now()

    @property
    def urgency(self) -> str:
        if self.retention < 0.3:
            return "urgent"
        if self.retention < 0.5:
            return "high"
        if self.retention < 0.7:
            return "medium"
        return "low"

    def to_dict(self) -> dict[str, Any]:
        return {
            "knowledge_id": self.knowledge_id,
            "retention": round(self.retention, 3),
            "days_since_review": round(self.days_since_review, 1),
            "urgency": self.urgency,
            "created_at": self.created_at.isoformat(),
        }


class CurriculumAgent(BaseAgent):
    """
    课程 Agent。

    职责：
    1. 规划学习路径
    2. 安排复习计划（SM-2 算法）
    3. 推荐下一学习主题
    4. 生成复习提醒
    5. 处理弱项补救路径

    事件流：
    - 订阅: MASTERY_UPDATED, WEAKNESS_DETECTED, PACE_ADJUSTMENT
    - 发布: NEXT_TOPIC, REVIEW_SCHEDULED, REVIEW_REMINDER
    """

    def __init__(
        self,
        event_bus,
        learner_models: dict[str, LearnerModel] | None = None,
        name: str = "CurriculumAgent",
        knowledge_graph=None,
        spaced_repetition=None,
        **_: Any,
    ) -> None:
        super().__init__(
            name=name,
            event_bus=event_bus,
            description="规划学习路径，安排复习计划",
            learner_models=learner_models,
        )
        self.knowledge_graph = knowledge_graph or build_english_learning_graph()
        self.sr = spaced_repetition or SpacedRepetition()
        self._review_items: dict[str, dict[str, ReviewItem]] = {}
        self._reminders: dict[str, list[ReviewReminder]] = {}
        self.register()

    def get_subscribed_events(self) -> list[EventType]:
        return [
            EventType.MASTERY_UPDATED,
            EventType.WEAKNESS_DETECTED,
            EventType.PACE_ADJUSTMENT,
        ]

    def seed_demo_data(self, learner_id: str) -> None:
        now = datetime.now()
        self._review_items[learner_id] = {
            "vocab_basic": ReviewItem(
                knowledge_id="vocab_basic",
                easiness_factor=2.5,
                interval_days=1,
                repetition=1,
                next_review=now - timedelta(days=2),
                last_review=now - timedelta(days=3),
                total_reviews=2,
            ),
            "vocab_intermediate": ReviewItem(
                knowledge_id="vocab_intermediate",
                easiness_factor=2.2,
                interval_days=3,
                repetition=2,
                next_review=now - timedelta(days=1),
                last_review=now - timedelta(days=4),
                total_reviews=3,
            ),
            "grammar_tenses": ReviewItem(
                knowledge_id="grammar_tenses",
                easiness_factor=1.8,
                interval_days=1,
                repetition=0,
                next_review=now,
                last_review=now - timedelta(days=1),
                total_reviews=1,
            ),
            "reading_skimming": ReviewItem(
                knowledge_id="reading_skimming",
                easiness_factor=2.4,
                interval_days=6,
                repetition=2,
                next_review=now + timedelta(days=3),
                last_review=now - timedelta(days=1),
                total_reviews=3,
            ),
            "writing_paragraph": ReviewItem(
                knowledge_id="writing_paragraph",
                easiness_factor=2.0,
                interval_days=1,
                repetition=0,
                next_review=now + timedelta(days=1),
                last_review=now,
                total_reviews=1,
            ),
        }

        model = self.get_learner_model(learner_id)
        demo_mastery = {
            "vocab_basic": (0.75, 4, 3),
            "vocab_intermediate": (0.55, 3, 2),
            "grammar_tenses": (0.3, 5, 1),
            "reading_skimming": (0.8, 3, 3),
            "writing_paragraph": (0.4, 2, 1),
        }
        for knowledge_id, (mastery, attempts, correct) in demo_mastery.items():
            state = model.get_state(knowledge_id)
            state.mastery = mastery
            state.attempts = attempts
            state.correct_count = correct

    async def handle_event(self, event: Event) -> Optional[dict[str, Any]]:
        if event.type == EventType.MASTERY_UPDATED:
            return await self._handle_mastery_update(event)
        elif event.type == EventType.WEAKNESS_DETECTED:
            return await self._handle_weakness(event)
        elif event.type == EventType.PACE_ADJUSTMENT:
            return await self._handle_pace_adjustment(event)
        return None

    async def _handle_mastery_update(self, event: Event) -> None:
        if not event.data.get("independent", True):
            return
        learner_id = event.learner_id
        knowledge_id = event.data.get("knowledge_id", "")
        mastery = float(event.data.get("mastery", 0.0))

        quality = (4 if event.data["is_correct"] else 1) if "is_correct" in event.data else self._mastery_to_quality(mastery)
        review_item = self._get_review_item(learner_id, knowledge_id)
        self.sr.review(review_item, quality)
        self.clear_reminder(learner_id, knowledge_id)
        strategy = await self._build_curriculum_strategy(learner_id, knowledge_id, mastery)

        await self.emit(
            EventType.LEARNING_PATH_UPDATE,
            learner_id,
            {
                "knowledge_id": knowledge_id,
                "curriculum_strategy": strategy,
            },
            correlation_id=event.correlation_id,
        )

        if mastery >= MASTERY_THRESHOLD:
            await self._check_and_recommend_next(learner_id, event.correlation_id)

        await self._send_review_schedule(learner_id, event.correlation_id)

    def _mastery_to_quality(self, mastery: float) -> int:
        if mastery >= 0.9:
            return 5
        if mastery >= 0.75:
            return 4
        if mastery >= 0.6:
            return 3
        if mastery >= 0.4:
            return 2
        if mastery >= 0.2:
            return 1
        return 0

    def _get_review_item(self, learner_id: str, knowledge_id: str) -> ReviewItem:
        learner_items = self._review_items.setdefault(learner_id, {})
        if knowledge_id not in learner_items:
            learner_items[knowledge_id] = ReviewItem(knowledge_id=knowledge_id)
        return learner_items[knowledge_id]

    async def _check_and_recommend_next(
        self,
        learner_id: str,
        correlation_id: str | None,
    ) -> None:
        model = self.get_learner_model(learner_id)
        mastered_ids = {
            state.knowledge_id
            for state in model.knowledge_states.values()
            if state.mastery >= MASTERY_THRESHOLD
        }

        ready = self.knowledge_graph.get_ready_nodes(mastered_ids)
        if not ready:
            return

        # Default fallback: first ready node
        next_topic = ready[0]
        node = self.knowledge_graph.nodes.get(next_topic)
        reason = "前置知识已经达到可推进水平，可以尝试进入下一知识点。"

        # Try LLM recommendation
        llm_service = get_llm_service()
        candidates = []
        for topic_id in ready[:6]:
            n = self.knowledge_graph.nodes.get(topic_id)
            candidates.append({
                "id": topic_id,
                "name": n.name if n else topic_id,
                "difficulty": n.difficulty if n else 0.5,
            })

        profile = self._build_learner_profile(learner_id)
        response = await llm_service.generate_next_topic_recommendation(candidates, profile)

        if response.content:
            try:
                import json
                parsed = json.loads(response.content)
                llm_id = parsed.get("knowledge_id", "")
                if llm_id and llm_id in {c["id"] for c in candidates}:
                    next_topic = llm_id
                    node = self.knowledge_graph.nodes.get(next_topic)
                    reason = parsed.get("reason", reason)
            except Exception:
                pass  # fallback to ready[0]

        await self.emit(
            EventType.NEXT_TOPIC,
            learner_id,
            {
                "knowledge_id": next_topic,
                "name": node.name if node else next_topic,
                "difficulty": node.difficulty if node else 0.5,
                "reason": reason,
                "alternatives": [t for t in ready[1:4] if t != next_topic],
            },
            correlation_id=correlation_id,
        )

    def _build_learner_profile(self, learner_id: str) -> dict[str, Any]:
        model = self.get_learner_model(learner_id)
        progress = model.get_overall_progress()
        weak = model.get_weak_points(limit=5)
        mastered = [
            state.knowledge_id
            for state in model.knowledge_states.values()
            if state.mastery >= MASTERY_THRESHOLD
        ]
        return {
            "mastered": "、".join(mastered) if mastered else "无",
            "weak_points": "、".join(w.knowledge_id for w in weak) if weak else "无",
            "avg_mastery": progress["avg_mastery"],
            "session_topics": "、".join(mastered[-3:]) if mastered else "无",
        }

    async def _build_curriculum_strategy(
        self,
        learner_id: str,
        knowledge_id: str,
        mastery: float,
    ) -> dict[str, Any]:
        """让 Curriculum Agent 基于路径、复习和薄弱项给出课程策略。"""
        model = self.get_learner_model(learner_id)
        weak = model.get_weak_points(limit=5)
        mastered = [
            state.knowledge_id
            for state in model.knowledge_states.values()
            if state.mastery >= MASTERY_THRESHOLD
        ]
        ready = self.knowledge_graph.get_ready_nodes(set(mastered))
        candidates = []
        for topic_id in ready[:6]:
            node = self.knowledge_graph.nodes.get(topic_id)
            candidates.append(
                {
                    "id": topic_id,
                    "name": node.name if node else topic_id,
                    "difficulty": node.difficulty if node else 0.5,
                }
            )
        due_items = self.get_top_due_items(learner_id, limit=5)

        if due_items:
            fallback_action = "review"
            fallback_plan = "优先处理到期复习，降低遗忘风险。"
            fallback_target = due_items[0]["knowledge_id"]
        elif mastery < 0.4:
            fallback_action = "remediate"
            fallback_plan = "当前知识点掌握偏低，先补救再推进。"
            fallback_target = knowledge_id
        elif candidates:
            fallback_action = "advance"
            fallback_plan = "前置条件基本满足，可以进入下一个可学习知识点。"
            fallback_target = candidates[0]["id"]
        else:
            fallback_action = "practice"
            fallback_plan = "继续用当前知识点做巩固练习。"
            fallback_target = knowledge_id

        fallback = {
            "plan": fallback_plan,
            "next_action": fallback_action,
            "target_knowledge_id": fallback_target,
            "reason": fallback_plan,
            "generation_mode": "local_policy",
        }

        if not settings.enable_agent_llm_decisions:
            return fallback

        response = await get_llm_service().generate_curriculum_strategy(
            {
                "knowledge_id": knowledge_id,
                "mastery": mastery,
                "weak_points": "、".join(w.knowledge_id for w in weak) if weak else "无",
                "mastered": "、".join(mastered) if mastered else "无",
                "candidates": candidates,
                "due_items": due_items,
            }
        )
        if not response.content:
            return fallback
        try:
            parsed = json.loads(response.content)
            if not isinstance(parsed, dict):
                return fallback
            action = parsed.get("next_action", fallback_action)
            target = parsed.get("target_knowledge_id", fallback_target)
            allowed = ({c["id"] for c in candidates} if action == "advance" else
                       {d["knowledge_id"] for d in due_items} if action == "review" else
                       {knowledge_id})
            if action not in {"advance", "review", "remediate", "practice"} or target not in allowed:
                return fallback
            if any(not isinstance(parsed.get(k, fallback[k]), str) for k in ("plan", "reason")):
                return fallback
        except Exception:
            return fallback

        parsed.setdefault("plan", fallback["plan"])
        parsed.setdefault("next_action", fallback["next_action"])
        parsed.setdefault("target_knowledge_id", fallback["target_knowledge_id"])
        parsed.setdefault("reason", fallback["reason"])
        parsed["generation_mode"] = "remote_llm"
        return parsed

    async def _send_review_schedule(
        self,
        learner_id: str,
        correlation_id: str | None,
    ) -> None:
        items = list(self._review_items.get(learner_id, {}).values())
        due_items = self.sr.get_due_items(items)
        schedule = self.sr.get_study_schedule(items, days_ahead=7)

        model = self.get_learner_model(learner_id)
        forgetting_items: list[dict[str, Any]] = []
        for item in items:
            if not item.last_review:
                continue
            days_since_review = (datetime.now() - item.last_review).total_seconds() / 86400
            retention = model.get_forgetting_curve(item.knowledge_id, days_since_review)
            if retention < 0.5:
                forgetting_items.append(
                    {
                        "knowledge_id": item.knowledge_id,
                        "retention": round(retention, 3),
                        "days_since_review": round(days_since_review, 1),
                    }
                )

        forgetting_items.sort(key=lambda item: item["retention"])
        if not due_items and not forgetting_items:
            return

        await self.emit(
            EventType.REVIEW_SCHEDULED,
            learner_id,
            {
                "due_now": [
                    {
                        "knowledge_id": item.knowledge_id,
                        "overdue_days": round(item.overdue_days, 1),
                    }
                    for item in due_items[:5]
                ],
                "about_to_forget": forgetting_items[:5],
                "weekly_schedule": schedule,
            },
            correlation_id=correlation_id,
        )

        reminders: list[ReviewReminder] = []
        for item in due_items[:5]:
            days_since_review = 0.0
            if item.last_review:
                days_since_review = (datetime.now() - item.last_review).total_seconds() / 86400
            reminders.append(
                ReviewReminder(
                    knowledge_id=item.knowledge_id,
                    retention=0.0,
                    days_since_review=days_since_review,
                )
            )
        for item in forgetting_items[:5]:
            reminders.append(
                ReviewReminder(
                    knowledge_id=item["knowledge_id"],
                    retention=item["retention"],
                    days_since_review=item["days_since_review"],
                )
            )

        self._reminders[learner_id] = reminders
        if reminders:
            await self.emit(
                EventType.REVIEW_REMINDER,
                learner_id,
                {
                    "reminders": [reminder.to_dict() for reminder in reminders],
                    "total_count": len(reminders),
                    "urgent_count": sum(
                        1 for reminder in reminders if reminder.urgency in {"urgent", "high"}
                    ),
                },
                correlation_id=correlation_id,
            )

    async def _handle_weakness(self, event: Event) -> None:
        learner_id = event.learner_id
        knowledge_id = event.data.get("knowledge_id", "")
        model = self.get_learner_model(learner_id)
        mastered_ids = {
            state.knowledge_id
            for state in model.knowledge_states.values()
            if state.mastery >= MASTERY_THRESHOLD
        }
        remedial_path = self.knowledge_graph.get_learning_path(knowledge_id, mastered_ids)
        logger.info(
            "[CurriculumAgent] weakness detected for %s: %s, remedial path=%s",
            learner_id,
            knowledge_id,
            remedial_path,
        )

    async def _handle_pace_adjustment(self, event: Event) -> None:
        action = event.data.get("action", "")
        learner_id = event.learner_id
        items = self._review_items.get(learner_id, {})

        if action == "slow_down":
            await self.emit(
                EventType.ENCOURAGEMENT,
                learner_id,
                {
                    "message": "我们先把节奏放慢一点，稳住基础，比硬赶进度更重要。",
                    "type": "pace_slow_down",
                },
                correlation_id=event.correlation_id,
            )
        elif action == "speed_up":
            logger.info("Challenge suggested for %s; review evidence remains unchanged", learner_id)

    def get_reminders(self, learner_id: str) -> list[dict[str, Any]]:
        reminders = self._reminders.get(learner_id, [])
        urgency_order = {"urgent": 0, "high": 1, "medium": 2, "low": 3}
        return [item.to_dict() for item in sorted(reminders, key=lambda item: urgency_order[item.urgency])]

    def clear_reminder(self, learner_id: str, knowledge_id: str) -> bool:
        if learner_id not in self._reminders:
            return False
        self._reminders[learner_id] = [
            reminder for reminder in self._reminders[learner_id] if reminder.knowledge_id != knowledge_id
        ]
        return True

    def get_top_due_items(self, learner_id: str, limit: int = 3) -> list[dict[str, Any]]:
        items = list(self._review_items.get(learner_id, {}).values())
        due_items = self.sr.get_due_items(items)
        return [
            {
                "knowledge_id": item.knowledge_id,
                "next_review": item.next_review.isoformat(),
                "overdue_days": round(item.overdue_days, 1),
            }
            for item in due_items[:limit]
        ]

    def get_review_snapshot(self, learner_id: str, knowledge_id: str) -> dict[str, Any]:
        item = self._review_items.get(learner_id, {}).get(knowledge_id)
        if item is None:
            return {
                "knowledge_id": knowledge_id,
                "next_review": None,
                "retention": None,
                "urgency": "low",
                "is_due": False,
                "days_since_review": None,
                "top_due_items": self.get_top_due_items(learner_id),
            }

        days_since_review = 0.0
        retention = 1.0
        if item.last_review:
            days_since_review = (datetime.now() - item.last_review).total_seconds() / 86400
            model = self.get_learner_model(learner_id)
            retention = model.get_forgetting_curve(knowledge_id, days_since_review)

        reminder = ReviewReminder(
            knowledge_id=knowledge_id,
            retention=retention,
            days_since_review=days_since_review,
        )
        return {
            "knowledge_id": knowledge_id,
            "next_review": item.next_review.isoformat(),
            "retention": round(retention, 3),
            "urgency": reminder.urgency,
            "is_due": item.is_due,
            "days_since_review": round(days_since_review, 1),
            "top_due_items": self.get_top_due_items(learner_id),
        }

    def get_state_for_save(self, learner_id: str) -> dict[str, Any] | None:
        reminders = self._reminders.get(learner_id, [])
        if reminders:
            return {"reminders": [reminder.to_dict() for reminder in reminders]}
        return None

    def load_state(self, learner_id: str, state_data: dict[str, Any]) -> None:
        reminders_data = state_data.get("reminders", [])
        if reminders_data:
            self._reminders[learner_id] = [
                ReviewReminder(
                    knowledge_id=item["knowledge_id"],
                    retention=item["retention"],
                    days_since_review=item["days_since_review"],
                )
                for item in reminders_data
            ]

    async def save_review_items(self, session: Any, learner_id: str) -> None:
        from sqlalchemy import select
        from models.database import ReviewItem as ReviewItemDB

        items = self._review_items.get(learner_id, {})
        for knowledge_id, item in items.items():
            result = await session.execute(
                select(ReviewItemDB).where(
                    ReviewItemDB.learner_id == learner_id,
                    ReviewItemDB.knowledge_id == knowledge_id,
                )
            )
            existing = result.scalar_one_or_none()
            if existing is None:
                session.add(
                    ReviewItemDB(
                        learner_id=learner_id,
                        knowledge_id=knowledge_id,
                        easiness_factor=item.easiness_factor,
                        interval_days=item.interval_days,
                        repetition=item.repetition,
                        next_review=item.next_review,
                        last_review=item.last_review,
                        total_reviews=item.total_reviews,
                    )
                )
            else:
                existing.easiness_factor = item.easiness_factor
                existing.interval_days = item.interval_days
                existing.repetition = item.repetition
                existing.next_review = item.next_review
                existing.last_review = item.last_review
                existing.total_reviews = item.total_reviews
        await session.commit()

    async def load_review_items(self, session: Any, learner_id: str) -> None:
        from sqlalchemy import select
        from models.database import ReviewItem as ReviewItemDB

        result = await session.execute(
            select(ReviewItemDB).where(ReviewItemDB.learner_id == learner_id)
        )
        rows = result.scalars().all()
        if not rows:
            return

        self._review_items[learner_id] = {}
        for row in rows:
            self._review_items[learner_id][row.knowledge_id] = ReviewItem(
                knowledge_id=row.knowledge_id,
                easiness_factor=row.easiness_factor,
                interval_days=row.interval_days,
                repetition=row.repetition,
                next_review=row.next_review,
                last_review=row.last_review,
                total_reviews=row.total_reviews,
            )
